#lang racket

;; dm.rkt
;; ------
;; Turtle-graphics helpers (axes, rectangles) + a few list utilities.
;;
;; Notes
;; - This file is written for DrRacket.
;; - Depending on your Racket version, the turtles library can be required in
;;   different ways. If the line below fails, try:
;;       (require graphics/turtles)
;;
;; Usage (example)
;;   (turtles #t)
;;   (initialize-centered!)
;;   (draw-horizontal-axis 300)
;;   (turn 90)
;;   (draw-vertical-axis 200 1)
;;
;; Nothing runs automatically when you press Run.

(require (lib "turtles.ss" "graphics"))

;; -----------------
;; Geometry drawing
;; -----------------

(define (draw-horizontal-axis length)
  "Draw a horizontal axis of the given LENGTH, then return to start position."
  (draw length)
  (move (- length)))

(define (draw-vertical-axis length scale)
  "Draw a vertical axis of LENGTH with tick marks every 5 units.

   SCALE multiplies every segment, useful if you want bigger drawings.
   After drawing, we return to the starting position and direction."
  (define (tick!)
    ;; little tick: go right, back to axis
    (turn -90)
    (draw (* scale 2))
    (move (- (* scale 2)))
    (turn 90))

  (define step (* scale 5))
  (turn 90) ; face upwards
  (let loop ([remaining length])
    (cond
      [(<= remaining 0)
       ;; return to starting point
       (move (- length))
       (turn -90)]
      [else
       (draw (min step remaining))
       (tick!)
       (loop (- remaining step))])))

(define (draw-rectangle height width)
  "Draw the outline of a rectangle (WIDTH x HEIGHT) and return to start." 
  (draw width)
  (turn 90)
  (draw height)
  (turn 90)
  (draw width)
  (turn 90)
  (draw height)
  (turn 90))

(define (draw-filled-rectangle height width)
  "Draw a filled rectangle by drawing WIDTH vertical strokes of HEIGHT.

   This is intentionally simple (no optimization): it demonstrates recursion." 
  (define (one-stroke!)
    (turn 90)
    (draw height)
    (move (- height))
    (turn -90))

  (let loop ([w width])
    (cond
      [(<= w 0) (move (- width))]
      [else
       (draw 1)
       (one-stroke!)
       (loop (- w 1))])))

(define (initialize-centered!)
  "Move the turtle so that the drawing starts near the center of the window." 
  (define offset (/ (- turtle-window-size 20) 2))
  ;; Go left then down so the next drawings fit in the window
  (move (- offset))
  (turn -90)
  (move offset)
  (turn 90))

;; -----------------
;; List utilities
;; -----------------

(define (maxList l)
  "Return the maximum element of a non-empty list of real numbers." 
  (cond
    [(null? l) (error 'maxList "empty list")]
    [(null? (cdr l)) (car l)]
    [else (max (car l) (maxList (cdr l)))]))

(define (scaleList lst n)
  "Multiply every element of LST by N." 
  (map (lambda (x) (* x n)) lst))

(define (readList n)
  "Read N values from stdin and return them as a list." 
  (if (= n 0)
      '()
      (cons (read) (readList (- n 1)))))
