#lang racket

;; TD3 - 16-02-2024
;; ---------------
;; Strings/characters + small interactive exercises.
;; This version fixes a few issues in the original draft:
;; - Adds missing language declaration (#lang racket) and the match import.
;; - Fixes conjugation printing (cleaner with printf).
;; - Fixes quadratic formula (the old version added 2a to the numerator).
;; - Fixes calculator operator and number conversion.
;; - Fixes guessing-game booleans and cond clauses.
;;
;; Nothing executes automatically: examples are commented.

(require racket/match)

;; ----------
;; Small helpers
;; ----------
(define (prompt/read msg)
  (display msg)
  (read))

(define (char->symbol c)
  "Convert a character to a symbol (e.g. #\a -> 'a)."
  (string->symbol (string c)))

(define (symbol->char sym)
  "Convert a one-character symbol to a character (e.g. 'a -> #\a)."
  (match (string->list (symbol->string sym))
    [(list ch) ch]
    [_ (error 'symbol->char "expected a one-character symbol, got: ~s" sym)]))

(define (vowel? c)
  "Case-insensitive vowel check for French/English vowels." 
  (member (char-downcase c) (list #\a #\e #\i #\o #\u #\y)))

;; -----------------
;; Exercise 1: French grammar mini-tools
;; -----------------

(define (first-group-verb? verb)
  "Return #t iff VERB (a string) ends with \"er\"." 
  (define n (string-length verb))
  (and (>= n 2)
       (string=? "er" (substring verb (- n 2) n))))

(define (conjugate-present-first-group verb)
  "Print present tense for a 1st-group French verb ending in -er." 
  (cond
    [(not (first-group-verb? verb))
     (printf "The given verb is not from the first group (-er).~n")]
    [else
     (define root (substring verb 0 (- (string-length verb) 2)))
     (define first-pronoun (if (vowel? (string-ref verb 0)) "j'" "je "))
     (printf "~a~ae~n" first-pronoun root)
     (printf "tu ~aes~n" root)
     (printf "il/elle/on ~ae~n" root)
     (printf "nous ~aons~n" root)
     (printf "vous ~aez~n" root)
     (printf "ils/elles ~aent~n" root)]))

;; (conjugate-present-first-group "manger")

(define (exercise1d)
  "Read (genre, noun) and print a French nominal group (le/la/l')." 
  (define genre (symbol->string (prompt/read "Genre? (m or f): ")))
  (define noun  (symbol->string (prompt/read "Noun?: ")))
  (define article
    (cond
      [(vowel? (string-ref noun 0)) "l'"]
      [(string=? genre "m") "le "]
      [(string=? genre "f") "la "]
      [else (error 'exercise1d "genre must be m or f, got: ~a" genre)]))
  (printf "~a~a~n" article noun))

;; (exercise1d)

;; -----------------
;; Exercise 2: final mark rule
;; -----------------

(define (max2 a b) (if (> a b) a b))
(define (min2 a b) (if (< a b) a b))

(define (max3 a b c) (max2 (max2 a b) c))
(define (min3 a b c) (min2 (min2 a b) c))

(define (avg2 a b) (/ (+ a b) 2))
(define (avg3 a b c) (/ (+ a b c) 3))

(define (finalMark a b c)
  "Final mark = max( average of 3, average(min, max) )." 
  (define a3 (avg3 a b c))
  (define mm (avg2 (min3 a b c) (max3 a b c)))
  (max2 a3 mm))

;; (finalMark 6 10 15)

;; -----------------
;; Exercise 3: common root of two quadratic equations
;; -----------------

(define (delta a b c)
  "Discriminant for ax^2 + bx + c = 0 (a != 0)." 
  (- (* b b) (* 4 a c)))

(define (root a b delta sign)
  "One root of ax^2+bx+c=0 given DELTA >= 0.
   SIGN must be +1 or -1 to choose +sqrt(delta) or -sqrt(delta)." 
  (/ (+ (- b) (* sign (sqrt delta))) (* 2 a)))

;; NOTE: A numerically stable version exists, but this is fine for exercises.

(define (exercise3)
  (printf "Equation 1: enter a b c (a != 0): ")
  (define a1 (read)) (define b1 (read)) (define c1 (read))
  (printf "Equation 2: enter a b c (a != 0): ")
  (define a2 (read)) (define b2 (read)) (define c2 (read))

  (define d1 (delta a1 b1 c1))
  (define d2 (delta a2 b2 c2))
  (cond
    [(or (< d1 0) (< d2 0))
     (printf "No common real solution (at least one equation has no real roots).~n")]
    [else
     (define r11 (root a1 b1 d1  1))
     (define r12 (root a1 b1 d1 -1))
     (define r21 (root a2 b2 d2  1))
     (define r22 (root a2 b2 d2 -1))
     (define common?
       (or (= r11 r21) (= r11 r22)
           (= r12 r21) (= r12 r22)))
     (printf (if common?
                 "There is at least one common real solution.~n"
                 "No common real solution.~n"))]))

;; (exercise3)

;; -----------------
;; Exercise 4: mini calculator of the form "a+b" (digits only)
;; -----------------

(define (digit->number ch)
  "Convert a digit character (#\0..#\9) to its numeric value." 
  (define code (- (char->integer ch) (char->integer #\0)))
  (if (and (<= 0 code) (<= code 9))
      code
      (error 'digit->number "expected a digit, got: ~a" ch)))

(define (calc a op b)
  "Compute a OP b where a and b are digit characters." 
  (define x (digit->number a))
  (define y (digit->number b))
  (case op
    [(#\+) (+ x y)]
    [(#\-) (- x y)]
    [(#\*) (* x y)]
    [(#\/) (/ x y)]
    [else (error 'calc "unknown operator: ~a" op)]))

(define (exercise4)
  (define sym (prompt/read "Give an operation to calculate (example: 3+5): "))
  (define s (symbol->string sym))
  (when (not (= (string-length s) 3))
    (error 'exercise4 "expected exactly 3 characters like 3+5, got: ~a" s))
  (define a (string-ref s 0))
  (define op (string-ref s 1))
  (define b (string-ref s 2))
  (printf "Result: ~a~n" (calc a op b)))

;; (exercise4)

;; -----------------
;; Exercise 5: guessing game (binary search by questions)
;; -----------------

(define (ask> x)
  (define ans (prompt/read (format "Is the number greater than ~a? (yes/no): " x)))
  (cond [(eq? ans 'yes) #t]
        [(eq? ans 'no)  #f]
        [else (error 'ask> "expected 'yes or 'no, got: ~a" ans)]))

(define (exercise5)
  "Guess an integer between 1 and 16 using yes/no questions." 
  (define (guess lo hi)
    (if (= lo hi)
        lo
        (let ([mid (quotient (+ lo hi) 2)])
          (if (ask> mid)
              (guess (+ mid 1) hi)
              (guess lo mid)))))
  (printf "It's: ~a~n" (guess 1 16)))

;; (exercise5)
