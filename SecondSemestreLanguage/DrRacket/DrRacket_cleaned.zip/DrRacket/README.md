# DrRacket / Racket – TD & Exam Files (cleaned)

This folder contains several `.rkt` files written for **DrRacket** (Racket language).
They were reorganized and commented so you can:

- quickly find each **exercise**,
- understand the **purpose**, **inputs/outputs**, and **key ideas**,
- avoid accidental execution when clicking **Run** (examples are commented).

## Quick start (DrRacket)

1. Open any `.rkt` file in DrRacket.
2. Click **Run**.
3. Evaluate examples by:
   - uncommenting the line, or
   - selecting an expression and pressing **Ctrl+Enter**.

## Files

- `g1-td1.rkt` – strings basics + geometric predicates (all examples commented).
- `g1-td2.rkt` – interactive I/O exercises + triangle/hexagon area + averages.
- `g1-td3.rkt` – characters/strings, conjugation tool, quadratic roots, mini calculator, guessing game.
- `g1-td4.rkt` – recursion practice: sums, powers, nth-root approximation, gcd, Fibonacci, sequences.
- `g1-td5.rkt` – reverse/mirror, palindromes, insertion sort, split sentence into words.
- `g1-TD-exam22-23.rkt` – exam practice on percent variations.
- `dm.rkt` – turtle-graphics helpers + a few list utilities (nothing auto-runs).

## Notes

- All files now start with `#lang racket`.
- Some names were improved for clarity, but backward-compatible aliases were kept when useful.
- `dm.rkt`: turtle graphics library import can vary by Racket version. If the default `require` fails,
  try `graphics/turtles` as indicated in the file.
