#lang racket

; TD2 - 09-02-2024
; ---------------
; Small interactive programs (I/O) + geometry/averages helpers.
;
; Tip: in DrRacket, prefer (printf ...) to avoid many (display ...) calls.

;; ----------
;; Tiny I/O helper
;; ----------
(define (prompt/read msg)
  (display msg)
  (read))

;Exercise 1
(define (exercise1)
  (define current-year 2024)
  (define birth-year (prompt/read "Please write your birth year: "))
  (define already? (prompt/read "Did you already celebrate your birthday this year? (yes/no): "))
  (define age
    (cond [(eq? already? 'yes) (- current-year birth-year)]
          [(eq? already? 'no)  (- (- current-year birth-year) 1)]
          [else (error 'exercise1 "Expected 'yes or 'no, got: ~a" already?)]))
  (printf "You are ~a years old.~n" age))


; Exercise 2
(define (exercise2)
  (define a (prompt/read "Please input an integer a (non-zero): "))
  (define b (prompt/read "Please input an integer b (non-zero): "))
  (when (= b 0) (error 'exercise2 "Division by 0 is not allowed"))

  (define add (+ a b))
  (define sub (- a b))
  (define mul (* a b))
  (define div (quotient a b))
  (define rem (remainder a b))

  (printf "A=~a, B=~a, A+B=~a, A-B=~a, A*B=~a, A/B=~a, remainder=~a~n"
          a b add sub mul div rem)
  (printf "A=~a~nB=~a~nA+B=~a~nA-B=~a~nA*B=~a~nA/B=~a~nremainder=~a~n"
          a b add sub mul div rem))

;Exercise 3
(define (triangleArea b h)
  ; returns the area of an triangle with the base b and the height h
  ; 2 real numbers >= 0 -> 1 real number >= 0
 (/ (* b h) 2))

(define (equilateralTriangleArea s)
  ; returns the area of an equilateral triangle with the side s
  ; 1 real number >= 0 -> 1 real number >= 0
  (triangleArea s (* (/ (sqrt 3) 2) s)))

(define (regularHexagon s)
  ; returns the area of a regular hexagon with the side s
  ; 1 real number >= 0 -> 1 real number >= 0
  (* 6 (equilateralTriangleArea s)))

; Backward-compatible name (in case it was used elsewhere)
(define regularHexagone regularHexagon)


(define (exercise3)
  (define side (prompt/read "Enter the side length s of the regular hexagon: "))
  (printf "Area = ~a~n" (regularHexagon side)))


;Exercise 4
(define (weightedAverage v1 v2 w1 w2)
  ; returns the weighted average of v1 and v2, with their respective weighs w1 and w2
  ; real, real > 0 -> real
  (/ (+ (* v1 w1) (* v2 w2)) (+ w1 w2)))

(define (exercise4b)
  ; program to get 6 inputs from the user and then calculate the average and the 
  ; weighted average
  ; 6 reals > 0 -> real for average and real for weigthed average
  (display "Please write 6 values\n")
  (define v1 (read)) (define v2 (read)) (define v3 (read)) 
  (define v4 (read)) (define v5 (read)) (define v6 (read)) 
  ; Non-weighted average, "normal average"
  (define nonWeightedAverage
    (weightedAverage (weightedAverage (weightedAverage v1 v2 1 1)
                                      (weightedAverage v3 v4 1 1)
                                      1 1)
                     (weightedAverage v5 v6 1 1)
                     2 1))
  (printf "The normal average is: ~a~n" nonWeightedAverage)

  ; Weighted average
  (display "Please write 6 weights\n")
  (define w1 (read)) (define w2 (read)) (define w3 (read)) 
  (define w4 (read)) (define w5 (read)) (define w6 (read)) 
  (define weightedAvg
    (weightedAverage (weightedAverage (weightedAverage v1 v2 w1 w2)
                                      (weightedAverage v3 v4 w3 w4)
                                      1 1)
                     (weightedAverage v5 v6 w5 w6)
                     2 1))
  (printf "The weighted average is: ~a~n" weightedAvg))
